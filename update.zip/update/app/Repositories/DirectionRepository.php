<?php

namespace App\Repositories;


interface DirectionRepository
{
    public function getAll();
}