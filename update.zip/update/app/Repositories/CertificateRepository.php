<?php

namespace App\Repositories;


interface CertificateRepository
{
    public function getAll();
}