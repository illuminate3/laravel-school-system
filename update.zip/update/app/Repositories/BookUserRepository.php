<?php

namespace App\Repositories;


interface BookUserRepository
{
    public function getAll();
}