<?php

namespace App\Repositories;


interface NoticeTypeRepository
{
    public function getAll();
}