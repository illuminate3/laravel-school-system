<?php

namespace App\Repositories;


interface BehaviorRepository
{
    public function getAll();
}