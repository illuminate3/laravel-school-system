<?php

namespace App\Repositories;


interface SemesterRepository
{
    public function getAll();
}