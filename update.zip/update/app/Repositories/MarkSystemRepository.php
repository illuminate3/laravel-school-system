<?php

namespace App\Repositories;


interface MarkSystemRepository
{
    public function getAll();
}