<?php

namespace App\Repositories;


interface MessageRepository
{
    public function getAll();
}