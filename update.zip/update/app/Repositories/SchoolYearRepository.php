<?php

namespace App\Repositories;


interface SchoolYearRepository
{
    public function getAll();
}