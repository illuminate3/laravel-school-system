<?php

namespace App\Repositories;


interface DormitoryRoomRepository
{
    public function getAll();
}