<?php

namespace App\Repositories;


interface FeeCategoryRepository
{
    public function getAll();
}