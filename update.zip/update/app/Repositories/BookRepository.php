<?php

namespace App\Repositories;


interface BookRepository
{
    public function getAll();
}