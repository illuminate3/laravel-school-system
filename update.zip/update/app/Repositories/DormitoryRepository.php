<?php

namespace App\Repositories;


interface DormitoryRepository
{
    public function getAll();
}