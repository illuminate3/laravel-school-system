<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NoticeType extends Model
{

    protected $guarded = array('id');

}
