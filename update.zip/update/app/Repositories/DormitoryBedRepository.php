<?php

namespace App\Repositories;


interface DormitoryBedRepository
{
    public function getAll();
}