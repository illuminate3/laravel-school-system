<?php

namespace App\Repositories;


interface PageRepository
{
    public function getAll();
}