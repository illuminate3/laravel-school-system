<?php

namespace App\Repositories;


interface ScholarshipRepository
{
    public function getAll();
}