<?php

namespace App\Repositories;


interface MarkTypeRepository
{
    public function getAll();
}