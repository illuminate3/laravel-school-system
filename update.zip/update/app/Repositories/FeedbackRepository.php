<?php

namespace App\Repositories;


interface FeedbackRepository
{
    public function getAll();
}