<?php

namespace App\Repositories;


interface NotificationRepository
{
    public function getAll();
}