<?php

namespace App\Repositories;


interface ParentStudentRepository
{
    public function getAll();
}